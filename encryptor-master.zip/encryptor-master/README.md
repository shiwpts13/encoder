# encryptor
With this tool you can turn English letters into meaningless aerial signs for others. And you can convert these meaningless symbols to your previous text.You can use this tool for messages that you do not want anyone to know their content
با این ابزار شما میتوانید کلمات فارسی را به عبا راتی بی معنا تبدیل کنید و سپس ان ها را دوباره با استفادازدژن تاز این ابزار به حالت قبلی خود تغییر دهید . اگر میخواهید کسی محوای پیام های شما کسی نداند از این ابزار استفاده کنید
